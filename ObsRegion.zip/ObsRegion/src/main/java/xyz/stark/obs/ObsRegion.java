package xyz.stark.obs;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockMultiPlaceEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPlaceEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ObsRegion extends JavaPlugin implements Listener {

    private record Entry(BlockState original, BukkitTask task) {}

    private String regionName;
    private long delayTicks;
    private Set<String> worlds = new HashSet<>();
    private boolean tBlocks, tBuckets, tFlow, tFire, tTrees, tEntities;

    private final Map<Location, Entry> pending = new HashMap<>();
    private final Set<Entity> entities = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
    }

    private void loadSettings() {
        reloadConfig();
        regionName = getConfig().getString("region", "obs");
        delayTicks = Math.max(1, getConfig().getLong("seconds", 30)) * 20L;
        worlds = new HashSet<>();
        for (String w : getConfig().getStringList("worlds")) worlds.add(w.toLowerCase());
        tBlocks = getConfig().getBoolean("track.blocks", true);
        tBuckets = getConfig().getBoolean("track.buckets", true);
        tFlow = getConfig().getBoolean("track.fluid-flow", true);
        tFire = getConfig().getBoolean("track.fire", true);
        tTrees = getConfig().getBoolean("track.trees", true);
        tEntities = getConfig().getBoolean("track.entities", true);
    }

    private String msg(String key) {
        return ChatColor.translateAlternateColorCodes('&', getConfig().getString("messages." + key, ""));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("obsregion.admin")) {
            sender.sendMessage(msg("no-permission"));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            loadSettings(); // المؤقتات الحالية تكمل بالمدة القديمة
            sender.sendMessage(msg("reloaded"));
        } else {
            sender.sendMessage(msg("usage"));
        }
        return true;
    }

    @Override
    public void onDisable() {
        for (Entry e : new ArrayList<>(pending.values())) {
            e.task().cancel();
            e.original().update(true, false);
        }
        pending.clear();
        for (Entity en : new ArrayList<>(entities)) {
            if (en.isValid()) en.remove();
        }
        entities.clear();
    }

    // ---------- بلوكات ----------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!tBlocks) return;
        List<BlockState> replaced = (e instanceof BlockMultiPlaceEvent multi)
                ? multi.getReplacedBlockStates()
                : List.of(e.getBlockReplacedState());
        for (BlockState s : replaced) track(s);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (!tBuckets) return;
        track(e.getBlock().getState());
    }

    // الماء/اللافا اللي ينساب من مصدر موضوع داخل المنطقة
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        if (!tFlow) return;
        if (!pending.containsKey(e.getBlock().getLocation())) return;
        if (pending.containsKey(e.getToBlock().getLocation())) return;
        track(e.getToBlock().getState());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (!tFire) return;
        track(e.getBlock().getState());
    }

    // أشجار من الشتلات / بون ميل
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGrow(StructureGrowEvent e) {
        if (!tTrees) return;
        for (BlockState s : e.getBlocks()) {
            track(s.getLocation().getBlock().getState());
        }
    }

    // ---------- كيانات (قوارب، أرمور ستاند، كريستال، إطارات...) ----------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityPlace(EntityPlaceEvent e) {
        if (!tEntities) return;
        trackEntity(e.getEntity());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent e) {
        if (!tEntities) return;
        trackEntity(e.getEntity());
    }

    // ---------- أدوات ----------

    private void track(BlockState state) {
        Location loc = state.getLocation();
        if (!inTarget(loc)) return;

        Entry old = pending.remove(loc);
        BlockState original = state;
        if (old != null) {
            old.task().cancel();
            original = old.original(); // نحتفظ بالحالة الأصلية الأولى
        }
        final BlockState toRestore = original;
        BukkitTask task = getServer().getScheduler().runTaskLater(this, () -> {
            pending.remove(loc);
            toRestore.update(true, false);
        }, delayTicks);
        pending.put(loc, new Entry(original, task));
    }

    private void trackEntity(Entity en) {
        if (!inTarget(en.getLocation())) return;
        entities.add(en);
        getServer().getScheduler().runTaskLater(this, () -> {
            entities.remove(en);
            if (en.isValid()) en.remove();
        }, delayTicks);
    }

    private boolean inTarget(Location loc) {
        World w = loc.getWorld();
        if (w == null) return false;
        if (!worlds.isEmpty() && !worlds.contains(w.getName().toLowerCase())) return false;
        RegionManager manager = WorldGuard.getInstance().getPlatform()
                .getRegionContainer().get(BukkitAdapter.adapt(w));
        if (manager == null) return false;
        for (ProtectedRegion r : manager.getApplicableRegions(BukkitAdapter.asBlockVector(loc))) {
            if (r.getId().equalsIgnoreCase(regionName)) return true;
        }
        return false;
    }
}
